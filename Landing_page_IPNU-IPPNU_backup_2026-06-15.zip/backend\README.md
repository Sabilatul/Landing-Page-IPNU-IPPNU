# IPNU-IPPNU Backend - XAMPP Database Setup Guide

## 📋 Prerequisites

Sebelum memulai, pastikan Anda telah menginstall:
- **XAMPP** ([Download](https://www.apachefriends.org/index.html))
- **Node.js** ([Download](https://nodejs.org/))
- **npm** atau **pnpm** (biasanya sudah terinstall dengan Node.js)

## 🗄️ Langkah 1: Setup Database XAMPP

### A. Jalankan XAMPP
1. Buka XAMPP Control Panel
2. Klik tombol **Start** untuk:
   - Apache
   - MySQL

### B. Import Database
1. Buka phpMyAdmin melalui browser: `http://localhost/phpmyadmin`
2. Login (default: username `root`, password kosong)
3. Buat database baru:
   - Klik "New" di sebelah kiri
   - Nama database: `ipnu_ippnu_db`
   - Charset: `utf8mb4_unicode_ci`
   - Klik "Create"

4. Import SQL Schema:
   - Klik database `ipnu_ippnu_db`
   - Pilih tab "Import"
   - Pilih file `backend/database.sql`
   - Klik "Import"

Atau manual menggunakan MySQL Command Line:
```bash
mysql -u root -p < backend/database.sql
```

## 🔧 Langkah 2: Setup Backend Node.js

### A. Install Dependencies Backend
```bash
cd backend
npm install
```

### B. Konfigurasi Environment (.env)
File `.env` sudah ada dengan konfigurasi default XAMPP:
```
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=
DB_NAME=ipnu_ippnu_db
SERVER_PORT=3001
NODE_ENV=development
```

Jika XAMPP MySQL menggunakan password, ubah `DB_PASSWORD` sesuai password Anda.

### C. Jalankan Backend Server
```bash
npm run dev
```

Server akan berjalan di: `http://localhost:3001`

Anda akan melihat output:
```
╔════════════════════════════════════════╗
║     IPNU-IPPNU Backend Server          ║
║     Listening on port 3001             ║
║     Database: ipnu_ippnu_db            ║
╚════════════════════════════════════════╝
```

## 🚀 Langkah 3: Jalankan Frontend

### Di direktori root (tidak backend):
```bash
npm install
npm run dev
```

Frontend akan berjalan di: `http://localhost:5173`

## 📡 API Endpoints

Berikut adalah API endpoints yang tersedia:

### 1. **Health Check**
```
GET /api/health
```

### 2. **Register Member (Pendaftaran)**
```
POST /api/members/register
Content-Type: application/json

{
  "name": "Nama Lengkap",
  "email": "email@example.com",
  "phone": "085848931819",
  "status": "Pelajar",
  "organization": "IPNU"
}
```

**Response Success (201):**
```json
{
  "success": true,
  "message": "Member registered successfully",
  "data": {
    "id": 1,
    "name": "Nama Lengkap",
    "email": "email@example.com",
    "phone": "085848931819",
    "status": "Pelajar",
    "organization": "IPNU"
  }
}
```

### 3. **Get All Members**
```
GET /api/members
```

### 4. **Get Member by ID**
```
GET /api/members/:id
```

### 5. **Update Member**
```
PUT /api/members/:id
Content-Type: application/json

{
  "name": "Nama Baru",
  "email": "email@example.com",
  "phone": "085848931819",
  "status": "Pelajar",
  "organization": "IPNU"
}
```

### 6. **Delete Member**
```
DELETE /api/members/:id
```

## 🛠️ Troubleshooting

### ❌ Error: "Cannot connect to MySQL"
- Pastikan XAMPP MySQL sudah dijalankan
- Cek konfigurasi di `.env`
- Jika masih error, coba:
  ```bash
  mysql -u root -p
  ```
  Jika berhasil masuk, DB setup OK

### ❌ Error: "Database not found"
- Import database lagi melalui phpMyAdmin
- Atau jalankan: `mysql -u root < backend/database.sql`

### ❌ Error: "Port 3001 already in use"
- Ubah `SERVER_PORT` di `.env`
- Atau kill process yang menggunakan port 3001:
  ```bash
  netstat -ano | findstr :3001
  taskkill /PID <PID> /F
  ```

### ❌ Error: "Email already registered"
- Email sudah terdaftar di database
- Gunakan email yang berbeda atau hapus record lama di phpMyAdmin

## 📊 Melihat Data di Database

1. Buka phpMyAdmin: `http://localhost/phpmyadmin`
2. Pilih database `ipnu_ippnu_db`
3. Pilih tabel `members`
4. Lihat semua data yang terdaftar

## 🔐 Security Notes

⚠️ **Untuk Production:**
- Jangan gunakan password kosong untuk MySQL
- Ubah DB_USER dan DB_PASSWORD dengan kredensial yang aman
- Update frontend CORS di backend jika deploy ke server berbeda
- Gunakan environment variables yang aman

## 📚 Struktur Backend

```
backend/
├── src/
│   ├── config/
│   │   └── database.js          (Konfigurasi koneksi DB)
│   ├── routes/
│   │   └── members.js           (API routes untuk members)
│   └── server.js                (Entry point server)
├── package.json
├── .env                         (Konfigurasi lokal)
├── .env.example                 (Template konfigurasi)
└── database.sql                 (SQL schema)
```

## 📞 Support

Jika ada masalah, periksa:
1. XAMPP MySQL running (port 3306)
2. Backend server running (port 3001)
3. Frontend server running (port 5173)
4. Database `ipnu_ippnu_db` exists
5. Check .env configuration
