import express from 'express';
import { getConnection } from '../config/database.js';

const router = express.Router();

// GET all members
router.get('/', async (req, res) => {
  try {
    const connection = await getConnection();
    const [members] = await connection.execute('SELECT * FROM members ORDER BY created_at DESC');
    connection.release();
    
    res.json({
      success: true,
      data: members,
      count: members.length
    });
  } catch (error) {
    console.error('Error fetching members:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching members',
      error: error.message
    });
  }
});

// GET member by ID
router.get('/:id', async (req, res) => {
  try {
    const connection = await getConnection();
    const [member] = await connection.execute(
      'SELECT * FROM members WHERE id = ?',
      [req.params.id]
    );
    connection.release();
    
    if (member.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Member not found'
      });
    }
    
    res.json({
      success: true,
      data: member[0]
    });
  } catch (error) {
    console.error('Error fetching member:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching member',
      error: error.message
    });
  }
});

// POST - Register new member
router.post('/register', async (req, res) => {
  try {
    const { name, email, phone, status, organization } = req.body;

    // Validation
    if (!name || !email || !phone) {
      return res.status(400).json({
        success: false,
        message: 'Please provide name, email, and phone'
      });
    }

    const connection = await getConnection();
    
    // Check if email already exists
    const [existing] = await connection.execute(
      'SELECT id FROM members WHERE email = ?',
      [email]
    );

    if (existing.length > 0) {
      connection.release();
      return res.status(400).json({
        success: false,
        message: 'Email already registered'
      });
    }

    // Insert new member
    const [result] = await connection.execute(
      'INSERT INTO members (name, email, phone, status, organization) VALUES (?, ?, ?, ?, ?)',
      [name, email, phone, status || 'Pelajar', organization || 'IPNU']
    );
    
    connection.release();

    res.status(201).json({
      success: true,
      message: 'Member registered successfully',
      data: {
        id: result.insertId,
        name,
        email,
        phone,
        status,
        organization
      }
    });
  } catch (error) {
    console.error('Error registering member:', error);
    res.status(500).json({
      success: false,
      message: 'Error registering member',
      error: error.message
    });
  }
});

// PUT - Update member
router.put('/:id', async (req, res) => {
  try {
    const { name, email, phone, status, organization } = req.body;
    const connection = await getConnection();

    // Check if member exists
    const [member] = await connection.execute(
      'SELECT id FROM members WHERE id = ?',
      [req.params.id]
    );

    if (member.length === 0) {
      connection.release();
      return res.status(404).json({
        success: false,
        message: 'Member not found'
      });
    }

    // Update member
    await connection.execute(
      'UPDATE members SET name = ?, email = ?, phone = ?, status = ?, organization = ? WHERE id = ?',
      [name, email, phone, status, organization, req.params.id]
    );

    connection.release();

    res.json({
      success: true,
      message: 'Member updated successfully'
    });
  } catch (error) {
    console.error('Error updating member:', error);
    res.status(500).json({
      success: false,
      message: 'Error updating member',
      error: error.message
    });
  }
});

// DELETE - Delete member
router.delete('/:id', async (req, res) => {
  try {
    const connection = await getConnection();

    const [result] = await connection.execute(
      'DELETE FROM members WHERE id = ?',
      [req.params.id]
    );

    connection.release();

    if (result.affectedRows === 0) {
      return res.status(404).json({
        success: false,
        message: 'Member not found'
      });
    }

    res.json({
      success: true,
      message: 'Member deleted successfully'
    });
  } catch (error) {
    console.error('Error deleting member:', error);
    res.status(500).json({
      success: false,
      message: 'Error deleting member',
      error: error.message
    });
  }
});

export default router;
