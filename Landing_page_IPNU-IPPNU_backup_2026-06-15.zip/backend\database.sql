-- IPNU-IPPNU Database Schema
-- Copy this SQL and run it in phpMyAdmin or MySQL command line

CREATE DATABASE IF NOT EXISTS ipnu_ippnu_db;
USE ipnu_ippnu_db;

-- Members Table
CREATE TABLE IF NOT EXISTS members (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  phone VARCHAR(20) NOT NULL,
  status VARCHAR(50),
  organization VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_email (email),
  INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert sample data (optional)
INSERT INTO members (name, email, phone, status, organization) VALUES
('Admin IPNU-IPPNU', 'admin@ipnu-ippnu.local', '085848931819', 'Pengurus', 'IPNU');
